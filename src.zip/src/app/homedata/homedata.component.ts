import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homedata',
  templateUrl: './homedata.component.html',
  styleUrls: ['./homedata.component.css']
})
export class homedataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
